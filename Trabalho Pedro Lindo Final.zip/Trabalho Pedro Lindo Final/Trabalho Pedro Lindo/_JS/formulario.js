
function validarForm() {
    const nomeRegex = /^[a-zA-Z\s]+$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const telefoneRegex = /\+\d{2}\s\(\d{2}\)\s\d{4,5}-?\d{4}/g;
    const idadeRegex = /^[0-9]+$/
    const esporteRegex = /^[a-zA-Z\s]+$/;

    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;
    const telefone = document.getElementById("telefone").value;
    const idade = document.getElementById("idade").value;
    const esporte = document.getElementById("esporte").value;

    if (!nomeRegex.test(nome)){
        window.alert("Nome inválido. Use apenas letras e espaços.")
        return false;
    }
    if (!emailRegex.test(email)){
        window.alert("E-mail inválido. Insira um e-mail válido.")
        return false;
    }
    if (!telefoneRegex.test(telefone)){
        window.alert("Telefone inválido. Utilize o modelo proposto e apenas números.")
        return false;
    }
    if (!idadeRegex.test(idade)){
        window.alert("Idade inválida, use apenas números.")
        return false;
    }
    if (!esporteRegex.test(esporte)){
        window.alert("Esporte inválido. Use apenas letras e espaços.")
        return false;
    }
    
    return true;
}
function guardar(){
    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;
    const telefone = document.getElementById("telefone").value;
    const idade = document.getElementById("idade").value;
    const esporte = document.getElementById("esporte").value;
    const turma = document.getElementById("turma").value;
    var formulario = document.getElementById('meuForm')

    formulario.style.height = '510px'

    document.querySelector("#dadosjson").textContent = "Nome: " + nome + "; E-mail: " + email + "; Telefone: " + telefone + "; Idade: " + idade + "; Turma: "  + turma + "; Esporte favorito: " + esporte; 
}





