function cadastroFuncao() {
    let tela = document.getElementById('telona')
    var apareça = document.getElementById('header')
    var limpo = document.getElementById("inicial")

    tela.src = '../HTML/formulario.html'
    tela.style.display = 'block'
    apareça.style.display = 'flex'
    limpo.style.display = 'none'
    tela.style.height = '740px'
}
function galeriaFuncao() {
    let tela = document.getElementById('telona')
    var apareça = document.getElementById('header')
    var limpo = document.getElementById("inicial")

    tela.src = '../HTML/galeria.html'
    tela.style.height = '1350px'
    tela.style.display = 'block'
    apareça.style.display = 'flex'
    limpo.style.display = 'none'
}
function agendaFuncao() {
    let tela = document.getElementById('telona')
    var apareça = document.getElementById('header')
    var limpo = document.getElementById("inicial")

    tela.src = '../HTML/calendario.html'
    tela.style.display = 'block'
    apareça.style.display = 'flex'
    limpo.style.display = 'none'
    tela.style.height = '1500px'
}
function limparFuncao() {
    let tela = document.getElementById('telona')
    var apareça = document.getElementById('header')
    var limpo = document.getElementById("inicial")

    tela.src = ''
    tela.style.display = 'none'
    apareça.style.display = 'none'
    limpo.style.display = 'block'
    tela.style.height = '0px'  
}