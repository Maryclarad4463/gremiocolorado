function eventoDiaSeis() {
    var um = document.getElementById('OAgaUm')
    var divFundo = document.getElementById('div-das-imagens')

    um.style.opacity = '1'
    divFundo.style.backgroundImage = 'url(../imagem/pedro.png)'
    divFundo.style.display = 'block'
    divFundo.style.width = '28%'
}

function eventoDiaDez() {
    var um = document.getElementById('OAgaUm')
    var divFundo = document.getElementById('div-das-imagens')
    um.style.opacity = '1'
    divFundo.style.backgroundImage = 'url(../imagem/culinaria.png)'
    divFundo.style.display = 'block'
    divFundo.style.width = '60%'
}

function eventoDiaDoze() {
    var um = document.getElementById('OAgaUm')
    var divFundo = document.getElementById('div-das-imagens')
    um.style.opacity = '1'
    divFundo.style.backgroundImage = 'url(../imagem/futsal.png)'
    divFundo.style.display = 'block'
    divFundo.style.width = '60%'
}

function eventoDiaVinteTres() {
    var um = document.getElementById('OAgaUm')
    var divFundo = document.getElementById('div-das-imagens')
    um.style.opacity = '1'
    divFundo.style.backgroundImage = 'url(../imagem/teatro.jpg)'
    divFundo.style.display = 'block'
    divFundo.style.width = '60%'
}

function eventoDiaVinteCinco() {
    var um = document.getElementById('OAgaUm')
    var divFundo = document.getElementById('div-das-imagens')
    um.style.opacity = '1'
    divFundo.style.backgroundImage = 'url(../imagem/vôlei.png)'
    divFundo.style.display = 'block'
    divFundo.style.width = '60%'
}
function eventoDiaCinco() {
    var um = document.getElementById('OAgaUm')
    var divFundo = document.getElementById('div-das-imagens')
    um.style.opacity = '1'
    divFundo.style.backgroundImage = 'url(../imagem/7.png)'
    divFundo.style.display = 'block'
    divFundo.style.width = '60%'
}

function zerarImagem() {
    var um = document.getElementById('OAgaUm')
    var divFundo = document.getElementById('div-das-imagens')
    um.style.opacity = '0'
    divFundo.style.backgroundImage = 'url()'
    divFundo.style.display = 'none'
}